import re
import ujson
from glob import glob

def find_us(loc):
    if loc is not None:
        is_us = False
        for x in ['United States', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York',
                  'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
                  'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia',
                  'Washington', 'West Virginia', 'Wisconsin', 'Wyoming','Los Angeles', 'Chicago', 'Houston', 'Phoenix',
                  'Philadelphia', 'San Antonio', 'San Diego',
                  'Dallas', 'San Jose', 'Austin', 'Jacksonville', 'Fort Worth', 'Columbus', 'San Francisco',
                  'Charlotte', 'Indianapolis', 'Seattle', 'Denver', 'Boston', 'El Paso', 'Detroit', 'Nashville',
                  'Portland', 'Memphis', 'Oklahoma City', '	Las Vegas', 'Louisville', 'Baltimore', 'Milwaukee',
                  'Albuquerque', 'Tucson', 'Fresno', 'Mesa', 'Sacramento', 'Atlanta', 'Kansas City',
                  'Colorado Springs', 'Miami', 'Raleigh', 'Omaha', 'Long Beach', 'Virginia Beach', 'Oakland',
                  'Minneapolis', 'Tulsa', 'Arlington', 'Tampa', 'New Orleans']:
            if re.search(x, str(loc), re.IGNORECASE):
                return True
        if not is_us:
            for y in ['USA', 'US', " AL", " AK", " AZ", " AR", " CA", " CO", " CT", " DC",
                      " DE", " FL", " GA", " HI", " ID", " IL", " IN", " IA", " KS", " KY",
                      " LA", " ME", " MD", " MA", " MI", " MN", " MS", " MO",
                      " MT", " NE", " NV", " NH", " NJ", " NM", " NY", " NC", " ND",
                      " OH", " OK", " OR", " PA", " RI", " SC", " SD", " TN",
                      " TX", " UT", " VT", " VA", " WA", " WV", " WI", " WY"]:
                if re.search(y, str(loc)):
                    return True
    return False

directory = './'
with open("corona_US_403.json", 'w') as output:
    for filename in glob(directory + '/data/corona*'):#output filename
            with open(filename, 'rb') as src: #input filename
                for line in src:
                    try:
                        json_string = line
                        twit = ujson.decode(json_string)

                # find tweets in US
                        if find_us(twit['user']['location']):
                            output.write(ujson.dumps(twit) + '\n')
                    except ValueError:
                        print("Couldn't save this line")
                        print(line)

