import ujson
import csv
from glob import glob

res = list()
#TODO: specify file directory here
directory = './'

bad = 0
for filename in glob(directory + '/corona*.json'):
    with open(filename, 'r') as input_file:

        print(filename)
        it = 0.0
        for line in input_file:
            try: 
                line = ujson.decode(line)
                user = line['user']
                user_id = user['id_str']
                date = line['timestamp_ms']
                
                tweet = ""
                if "delete" not in line:
                    is_retweet = True if (line["text"].startswith("RT @")) else False
                    if "retweeted_status" in line:
                        if is_retweet:
                            if "extended_tweet" in line["retweeted_status"]:
                                tweet = line["retweeted_status"]["extended_tweet"]["full_text"]
                            else:
                                tweet = line["retweeted_status"]["text"]
                        else:
                            tweet = line["extended_tweet"]["full_text"] if "extended_tweet" in line else line["text"]
                    else:
                        tweet = line["extended_tweet"]["full_text"] if "extended_tweet" in line else line["text"]
                res.append([user_id, tweet, date])
            except: 
                bad = bad + 1
                print('error found! at:' + filename + str(it))
                
            it = it + 1
            if it%10000.0 == 0:
                print(it)

print('total bad files: '+str(bad)) 

                
with open('corono_403_id_text_date_US.csv', 'w', encoding='utf-8') as output_file:
    writer = csv.writer(output_file)
    writer.writerow(['user_id','tweet', 'date'])
    
    for entry in res:
        writer.writerow(entry)