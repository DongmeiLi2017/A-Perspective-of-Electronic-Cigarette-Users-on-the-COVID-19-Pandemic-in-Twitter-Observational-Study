import pandas as pd

file1 = pd.read_csv('twitter_ecig_unique_UserId_2019.csv', low_memory=False)
file2 = pd.read_csv('corono_403_id_text_date_US.csv', low_memory=False)

df1 = file1[['user_id']]
df2 = file2[['user_id']]
df = df1.merge(df2,how='outer',indicator=True).loc[lambda x:x['_merge']=='right_only']
joined = pd.merge(df, file2, left_on='user_id', right_on='user_id')
f = joined.drop_duplicates(keep='first')
f.to_csv('corona_nonecig_users_403_US_2019.csv', index=False)