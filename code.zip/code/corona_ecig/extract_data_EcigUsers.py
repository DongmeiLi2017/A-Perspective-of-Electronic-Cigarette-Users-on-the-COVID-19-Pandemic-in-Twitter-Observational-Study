import pandas as pd

file1 = pd.read_csv('twitter_ecig_unique_UserId_2019.csv', low_memory=False)
file2 = pd.read_csv('corono_403_id_text_date_US.csv', low_memory=False)

joined = pd.merge(file1, file2, left_on='user_id', right_on='user_id')
joined.to_csv('corona_EcigUsers_403_US.csv', index=False)
       