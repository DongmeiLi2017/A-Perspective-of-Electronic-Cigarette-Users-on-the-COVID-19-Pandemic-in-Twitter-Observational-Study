import csv
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import re

analyzer = SentimentIntensityAnalyzer()


with open('corona_nonecig_users_US_2019.csv','r',encoding='utf-8') as sentiment_file: #input file
    reader = csv.reader(sentiment_file)
    next(reader)
    with open('sentiment_result_nonecig_users_US_2019.csv', 'w', encoding='utf-8') as output_file:   #output file
        writer = csv.writer(output_file)
        writer.writerow(["posts","sentiment_score","user_id","datetime"]) #column 1 is the Twitter post, column 2 is the flavor name, column 3 is the sentiment score
        for line in reader:
            if line: 
                post = re.sub(r'\s+', ' ', line[2])
                sentiment_score = analyzer.polarity_scores(post)['compound']  #sentiment analysis
                writer.writerow([line[2], sentiment_score, line[1], line[3]])   #write output file

