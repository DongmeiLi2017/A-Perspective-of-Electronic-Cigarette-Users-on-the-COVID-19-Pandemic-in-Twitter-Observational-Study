import ujson
import csv



with open('twitter_ecig_UserId_2019.csv', 'w', encoding="utf-8") as output_file:
    with open("filtered_ecig_promo.json", 'r') as input_file:
        
        writer = csv.writer(output_file)
        writer.writerow(['user_id','user_name'])
        
        for line in input_file:
            res = list()
            line = ujson.decode(line)
            user = line['user']
            user_id = user['id']
            user_name = user['name']
            res.append([user_id, user_name])
            for entry in res:
                writer.writerow(entry)



    
