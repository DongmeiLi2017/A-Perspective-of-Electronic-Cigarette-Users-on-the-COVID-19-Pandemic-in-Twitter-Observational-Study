import ujson


files = ["May30.json", "Jul11.json", "Jun27.json","Aug02.json"]

with open("mergedFile.json", "w") as output:
    for f in files:
        with open(f, "rb") as infile:
            for line in infile:
                parsedJsonRecord = ujson.decode(line)
                output.write(ujson.dumps(parsedJsonRecord) + '\n')
                

